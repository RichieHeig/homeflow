/*
  # Create HomeFlow Database Schema

  1. New Tables
    - `households`
      - `id` (uuid, primary key)
      - `name` (text) - Nom du foyer
      - `join_code` (text, unique) - Code pour rejoindre le foyer
      - `created_at` (timestamptz)
      - `deleted_at` (timestamptz, nullable) - Soft delete
    
    - `members`
      - `id` (uuid, primary key, references auth.users)
      - `household_id` (uuid, foreign key -> households)
      - `display_name` (text) - Nom affiché
      - `avatar_url` (text, nullable)
      - `role` (text) - 'admin' ou 'member'
      - `energy_profile` (text, nullable) - Profil énergétique
      - `created_at` (timestamptz)
    
    - `tasks`
      - `id` (uuid, primary key)
      - `household_id` (uuid, foreign key -> households)
      - `title` (text) - Titre de la tâche
      - `category` (text) - Catégorie
      - `duration_min` (integer) - Durée estimée
      - `difficulty` (smallint) - 1, 2 ou 3
      - `frequency_days` (integer, nullable) - Fréquence en jours
      - `last_completed_at` (timestamptz, nullable)
      - `deleted_at` (timestamptz, nullable) - Soft delete
      - `created_at` (timestamptz)
  
  2. Functions
    - `get_my_household()` - Retourne le foyer de l'utilisateur connecté
  
  3. Security
    - Enable RLS on all tables
    - Members can only see their own household data
    - Admins have full control within their household
*/

-- Create households table
CREATE TABLE IF NOT EXISTS households (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  join_code text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now(),
  deleted_at timestamptz DEFAULT NULL
);

ALTER TABLE households ENABLE ROW LEVEL SECURITY;

-- Create members table
CREATE TABLE IF NOT EXISTS members (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  household_id uuid NOT NULL REFERENCES households(id) ON DELETE CASCADE,
  display_name text NOT NULL,
  avatar_url text DEFAULT NULL,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  energy_profile text DEFAULT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE members ENABLE ROW LEVEL SECURITY;

-- Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  household_id uuid NOT NULL REFERENCES households(id) ON DELETE CASCADE,
  title text NOT NULL,
  category text NOT NULL,
  duration_min integer NOT NULL,
  difficulty smallint NOT NULL CHECK (difficulty IN (1, 2, 3)),
  frequency_days integer DEFAULT NULL,
  last_completed_at timestamptz DEFAULT NULL,
  deleted_at timestamptz DEFAULT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- Create function to get user's household
CREATE OR REPLACE FUNCTION get_my_household()
RETURNS TABLE (
  id uuid,
  name text,
  join_code text,
  created_at timestamptz,
  deleted_at timestamptz
) 
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT h.id, h.name, h.join_code, h.created_at, h.deleted_at
  FROM households h
  INNER JOIN members m ON m.household_id = h.id
  WHERE m.id = auth.uid()
  AND h.deleted_at IS NULL
  LIMIT 1;
$$;

-- RLS Policies for households
CREATE POLICY "Members can view their household"
  ON households FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "Admins can update their household"
  ON households FOR UPDATE
  TO authenticated
  USING (
    id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Authenticated users can create households"
  ON households FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for members
CREATE POLICY "Members can view household members"
  ON members FOR SELECT
  TO authenticated
  USING (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "Users can insert themselves as members"
  ON members FOR INSERT
  TO authenticated
  WITH CHECK (id = auth.uid());

CREATE POLICY "Members can update their own profile"
  ON members FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

CREATE POLICY "Admins can update household members"
  ON members FOR UPDATE
  TO authenticated
  USING (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid() AND role = 'admin'
    )
  )
  WITH CHECK (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- RLS Policies for tasks
CREATE POLICY "Members can view household tasks"
  ON tasks FOR SELECT
  TO authenticated
  USING (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid()
    )
    AND deleted_at IS NULL
  );

CREATE POLICY "Members can create household tasks"
  ON tasks FOR INSERT
  TO authenticated
  WITH CHECK (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "Members can update household tasks"
  ON tasks FOR UPDATE
  TO authenticated
  USING (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid()
    )
  )
  WITH CHECK (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "Admins can delete household tasks"
  ON tasks FOR DELETE
  TO authenticated
  USING (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_members_household_id ON members(household_id);
CREATE INDEX IF NOT EXISTS idx_tasks_household_id ON tasks(household_id);
CREATE INDEX IF NOT EXISTS idx_tasks_deleted_at ON tasks(deleted_at) WHERE deleted_at IS NULL;