/*
  # Fix auth.uid() Access in SECURITY DEFINER Functions

  1. Problem
    - Functions using SECURITY DEFINER with SET search_path = public
    - This excludes the auth schema, causing auth.uid() to fail
    - Results in "null value in column id" errors

  2. Solution
    - Update all functions to include auth schema in search_path
    - Change: SET search_path = public
    - To: SET search_path = public, auth
    - Add explicit validation that auth.uid() is not null

  3. Functions Updated
    - create_household
    - join_household_via_code
    - complete_task
    - promote_to_admin
    - demote_from_admin
    - remove_member
    - leave_household
    - regenerate_join_code
    - delete_account
*/

-- Function to create a new household
CREATE OR REPLACE FUNCTION create_household(
  _household_name text,
  _display_name text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  new_household households;
  new_member members;
  result jsonb;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Validate inputs
  IF trim(_household_name) = '' THEN
    RAISE EXCEPTION 'Household name cannot be empty';
  END IF;
  
  IF trim(_display_name) = '' THEN
    RAISE EXCEPTION 'Display name cannot be empty';
  END IF;
  
  -- Check if user is already a member of another household
  IF EXISTS (SELECT 1 FROM members WHERE id = current_user_id) THEN
    RAISE EXCEPTION 'User is already a member of a household';
  END IF;
  
  -- Create the household
  INSERT INTO households (name, join_code)
  VALUES (trim(_household_name), generate_join_code())
  RETURNING * INTO new_household;
  
  -- Create the member as admin
  INSERT INTO members (id, household_id, display_name, role)
  VALUES (current_user_id, new_household.id, trim(_display_name), 'admin')
  RETURNING * INTO new_member;
  
  -- Build result
  result := jsonb_build_object(
    'household', to_jsonb(new_household),
    'member', to_jsonb(new_member)
  );
  
  RETURN result;
END;
$$;

-- Function to join a household via code
CREATE OR REPLACE FUNCTION join_household_via_code(
  _join_code text,
  _display_name text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  target_household households;
  new_member members;
  result jsonb;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Validate inputs
  IF trim(_join_code) = '' THEN
    RAISE EXCEPTION 'Join code cannot be empty';
  END IF;
  
  IF trim(_display_name) = '' THEN
    RAISE EXCEPTION 'Display name cannot be empty';
  END IF;
  
  -- Find the household
  SELECT * INTO target_household
  FROM households
  WHERE join_code = upper(trim(_join_code))
    AND deleted_at IS NULL;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invalid join code';
  END IF;
  
  -- Check if user is already a member of this household
  IF EXISTS (
    SELECT 1 FROM members 
    WHERE id = current_user_id
      AND household_id = target_household.id
  ) THEN
    RAISE EXCEPTION 'User is already a member of this household';
  END IF;
  
  -- Check if user is a member of another household
  IF EXISTS (SELECT 1 FROM members WHERE id = current_user_id) THEN
    RAISE EXCEPTION 'User is already a member of another household';
  END IF;
  
  -- Create the member
  INSERT INTO members (id, household_id, display_name, role)
  VALUES (current_user_id, target_household.id, trim(_display_name), 'member')
  RETURNING * INTO new_member;
  
  -- Build result
  result := jsonb_build_object(
    'household', to_jsonb(target_household),
    'member', to_jsonb(new_member)
  );
  
  RETURN result;
END;
$$;

-- Function to complete a task
CREATE OR REPLACE FUNCTION complete_task(
  p_task_id uuid,
  p_member_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_household_id uuid;
  v_task_difficulty smallint;
  v_points integer;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Get task info
  SELECT household_id, difficulty INTO v_household_id, v_task_difficulty
  FROM tasks
  WHERE id = p_task_id AND deleted_at IS NULL;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Task not found';
  END IF;
  
  -- Verify member belongs to the household
  IF NOT EXISTS (
    SELECT 1 FROM members 
    WHERE id = p_member_id 
      AND household_id = v_household_id
  ) THEN
    RAISE EXCEPTION 'Member does not belong to this household';
  END IF;
  
  -- Verify caller is a member of the same household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = current_user_id
      AND household_id = v_household_id
  ) THEN
    RAISE EXCEPTION 'You are not a member of this household';
  END IF;
  
  -- Calculate points based on difficulty
  v_points := CASE v_task_difficulty
    WHEN 1 THEN 10
    WHEN 2 THEN 20
    WHEN 3 THEN 30
    ELSE 10
  END;
  
  -- Update task last_completed_at
  UPDATE tasks
  SET last_completed_at = now()
  WHERE id = p_task_id;
  
  -- Create completion record
  INSERT INTO task_completions (task_id, member_id, household_id, points_earned)
  VALUES (p_task_id, p_member_id, v_household_id, v_points);
END;
$$;

-- Function to promote member to admin
CREATE OR REPLACE FUNCTION promote_to_admin(p_member_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_household_id uuid;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Get target member's household
  SELECT household_id INTO v_household_id
  FROM members
  WHERE id = p_member_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Member not found';
  END IF;
  
  -- Verify caller is admin of the same household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = current_user_id
      AND household_id = v_household_id
      AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only admins can promote members';
  END IF;
  
  -- Promote member
  UPDATE members
  SET role = 'admin'
  WHERE id = p_member_id;
END;
$$;

-- Function to demote admin to member
CREATE OR REPLACE FUNCTION demote_from_admin(p_member_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_household_id uuid;
  v_admin_count integer;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Get target member's household
  SELECT household_id INTO v_household_id
  FROM members
  WHERE id = p_member_id AND role = 'admin';
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Admin member not found';
  END IF;
  
  -- Verify caller is admin of the same household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = current_user_id
      AND household_id = v_household_id
      AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only admins can demote members';
  END IF;
  
  -- Check if this is the last admin
  SELECT COUNT(*) INTO v_admin_count
  FROM members
  WHERE household_id = v_household_id AND role = 'admin';
  
  IF v_admin_count <= 1 THEN
    RAISE EXCEPTION 'Cannot demote the last admin';
  END IF;
  
  -- Demote member
  UPDATE members
  SET role = 'member'
  WHERE id = p_member_id;
END;
$$;

-- Function to remove a member
CREATE OR REPLACE FUNCTION remove_member(p_member_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_household_id uuid;
  v_target_role text;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Get target member's info
  SELECT household_id, role INTO v_household_id, v_target_role
  FROM members
  WHERE id = p_member_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Member not found';
  END IF;
  
  -- Verify caller is admin of the same household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = current_user_id
      AND household_id = v_household_id
      AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only admins can remove members';
  END IF;
  
  -- Cannot remove yourself via this function
  IF p_member_id = current_user_id THEN
    RAISE EXCEPTION 'Cannot remove yourself. Use leave_household instead';
  END IF;
  
  -- Delete member (cascade will handle related records)
  DELETE FROM members WHERE id = p_member_id;
END;
$$;

-- Function to leave household
CREATE OR REPLACE FUNCTION leave_household()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_household_id uuid;
  v_member_count integer;
  v_is_admin boolean;
  v_admin_count integer;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Get current user's household and role
  SELECT household_id, (role = 'admin') INTO v_household_id, v_is_admin
  FROM members
  WHERE id = current_user_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Not a member of any household';
  END IF;
  
  -- Count members in household
  SELECT COUNT(*) INTO v_member_count
  FROM members
  WHERE household_id = v_household_id;
  
  -- If last member, soft-delete the household
  IF v_member_count = 1 THEN
    UPDATE households
    SET deleted_at = now()
    WHERE id = v_household_id;
  ELSIF v_is_admin THEN
    -- Check if this is the last admin
    SELECT COUNT(*) INTO v_admin_count
    FROM members
    WHERE household_id = v_household_id AND role = 'admin';
    
    IF v_admin_count = 1 THEN
      RAISE EXCEPTION 'Cannot leave: you are the last admin. Promote another member first';
    END IF;
  END IF;
  
  -- Remove member
  DELETE FROM members WHERE id = current_user_id;
END;
$$;

-- Function to regenerate join code
CREATE OR REPLACE FUNCTION regenerate_join_code(p_household_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  new_code text;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Verify caller is admin of this household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = current_user_id
      AND household_id = p_household_id
      AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only admins can regenerate the join code';
  END IF;
  
  -- Generate new code
  new_code := generate_join_code();
  
  -- Update household
  UPDATE households
  SET join_code = new_code
  WHERE id = p_household_id;
  
  RETURN new_code;
END;
$$;

-- Function to delete account
CREATE OR REPLACE FUNCTION delete_account()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_household_id uuid;
  v_member_count integer;
  v_is_admin boolean;
  v_admin_count integer;
  current_user_id uuid;
BEGIN
  -- Get and validate current user
  current_user_id := auth.uid();
  
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Get current user's household info
  SELECT household_id, (role = 'admin') INTO v_household_id, v_is_admin
  FROM members
  WHERE id = current_user_id;
  
  IF FOUND THEN
    -- Count members and admins
    SELECT COUNT(*) INTO v_member_count
    FROM members
    WHERE household_id = v_household_id;
    
    SELECT COUNT(*) INTO v_admin_count
    FROM members
    WHERE household_id = v_household_id AND role = 'admin';
    
    -- If last member, soft-delete household
    IF v_member_count = 1 THEN
      UPDATE households
      SET deleted_at = now()
      WHERE id = v_household_id;
    ELSIF v_is_admin AND v_admin_count = 1 THEN
      RAISE EXCEPTION 'Cannot delete account: you are the last admin. Promote another member first';
    END IF;
  END IF;
  
  -- Delete from auth.users will cascade to members and other records
  DELETE FROM auth.users WHERE id = current_user_id;
END;
$$;
