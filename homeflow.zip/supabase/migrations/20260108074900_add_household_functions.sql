/*
  # Add Household Management Functions

  1. New Functions
    - `create_household(_household_name, _display_name)`
      - Génère un code d'invitation unique aléatoire (8 caractères)
      - Crée un nouveau foyer
      - Crée le membre avec le rôle 'admin'
      - Retourne un objet JSON contenant le household et le member
    
    - `join_household_via_code(_join_code, _display_name)`
      - Vérifie que le code d'invitation existe et est valide
      - Vérifie que l'utilisateur n'est pas déjà membre du foyer
      - Crée le membre avec le rôle 'member'
      - Retourne un objet JSON contenant le household et le member

  2. Security
    - Les deux fonctions utilisent SECURITY DEFINER pour gérer les RLS
    - Validation des données d'entrée
    - Protection contre les doublons

  3. Notes Importantes
    - Les codes d'invitation sont en majuscules
    - Format: 8 caractères alphanumériques (sans ambiguïté: pas de 0, O, I, 1)
    - Les fonctions retournent du JSONB pour faciliter l'utilisation côté client
*/

-- Helper function to generate unique join codes
CREATE OR REPLACE FUNCTION generate_join_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; -- Exclude ambiguous chars
  result text := '';
  i integer;
  code_exists boolean;
BEGIN
  LOOP
    result := '';
    FOR i IN 1..8 LOOP
      result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
    END LOOP;
    
    SELECT EXISTS(SELECT 1 FROM households WHERE join_code = result) INTO code_exists;
    
    EXIT WHEN NOT code_exists;
  END LOOP;
  
  RETURN result;
END;
$$;

-- Function to create a new household
CREATE OR REPLACE FUNCTION create_household(
  _household_name text,
  _display_name text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_household households;
  new_member members;
  result jsonb;
BEGIN
  -- Validate inputs
  IF trim(_household_name) = '' THEN
    RAISE EXCEPTION 'Household name cannot be empty';
  END IF;
  
  IF trim(_display_name) = '' THEN
    RAISE EXCEPTION 'Display name cannot be empty';
  END IF;
  
  -- Check if user is already a member of another household
  IF EXISTS (SELECT 1 FROM members WHERE id = auth.uid()) THEN
    RAISE EXCEPTION 'User is already a member of a household';
  END IF;
  
  -- Create the household
  INSERT INTO households (name, join_code)
  VALUES (trim(_household_name), generate_join_code())
  RETURNING * INTO new_household;
  
  -- Create the member as admin
  INSERT INTO members (id, household_id, display_name, role)
  VALUES (auth.uid(), new_household.id, trim(_display_name), 'admin')
  RETURNING * INTO new_member;
  
  -- Build result
  result := jsonb_build_object(
    'household', to_jsonb(new_household),
    'member', to_jsonb(new_member)
  );
  
  RETURN result;
END;
$$;

-- Function to join a household via code
CREATE OR REPLACE FUNCTION join_household_via_code(
  _join_code text,
  _display_name text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_household households;
  new_member members;
  result jsonb;
BEGIN
  -- Validate inputs
  IF trim(_join_code) = '' THEN
    RAISE EXCEPTION 'Join code cannot be empty';
  END IF;
  
  IF trim(_display_name) = '' THEN
    RAISE EXCEPTION 'Display name cannot be empty';
  END IF;
  
  -- Find the household
  SELECT * INTO target_household
  FROM households
  WHERE join_code = upper(trim(_join_code))
    AND deleted_at IS NULL;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Invalid join code';
  END IF;
  
  -- Check if user is already a member of this household
  IF EXISTS (
    SELECT 1 FROM members 
    WHERE id = auth.uid() 
      AND household_id = target_household.id
  ) THEN
    RAISE EXCEPTION 'User is already a member of this household';
  END IF;
  
  -- Check if user is a member of another household
  IF EXISTS (SELECT 1 FROM members WHERE id = auth.uid()) THEN
    RAISE EXCEPTION 'User is already a member of another household';
  END IF;
  
  -- Create the member
  INSERT INTO members (id, household_id, display_name, role)
  VALUES (auth.uid(), target_household.id, trim(_display_name), 'member')
  RETURNING * INTO new_member;
  
  -- Build result
  result := jsonb_build_object(
    'household', to_jsonb(target_household),
    'member', to_jsonb(new_member)
  );
  
  RETURN result;
END;
$$;
