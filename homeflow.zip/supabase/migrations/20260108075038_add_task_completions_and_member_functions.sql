/*
  # Add Task Completions, Leaderboard & Member Management Functions

  1. New Tables
    - `task_completions`
      - `id` (uuid, primary key)
      - `task_id` (uuid, foreign key -> tasks)
      - `member_id` (uuid, foreign key -> members)
      - `household_id` (uuid, foreign key -> households)
      - `points_earned` (integer) - Points gagnés pour cette complétion
      - `completed_at` (timestamptz)
  
  2. New Views
    - `household_leaderboard` - Classement des membres avec statistiques
      - Agrège les points, nombre de tâches, etc.
  
  3. New Functions
    - `complete_task(p_task_id, p_member_id)` - Marque une tâche comme complétée
    - `promote_to_admin(p_member_id)` - Promouvoir un membre en admin
    - `demote_from_admin(p_member_id)` - Rétrograder un admin en membre
    - `remove_member(p_member_id)` - Supprimer un membre du foyer
    - `leave_household()` - Quitter son foyer
    - `regenerate_join_code(p_household_id)` - Régénérer le code d'invitation
    - `delete_account()` - Supprimer son compte définitivement
  
  4. Security
    - RLS sur task_completions
    - Validation des permissions dans les fonctions
*/

-- Create task_completions table
CREATE TABLE IF NOT EXISTS task_completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  member_id uuid NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  household_id uuid NOT NULL REFERENCES households(id) ON DELETE CASCADE,
  points_earned integer NOT NULL DEFAULT 0,
  completed_at timestamptz DEFAULT now()
);

ALTER TABLE task_completions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for task_completions
CREATE POLICY "Members can view household completions"
  ON task_completions FOR SELECT
  TO authenticated
  USING (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid()
    )
  );

CREATE POLICY "Members can create completions"
  ON task_completions FOR INSERT
  TO authenticated
  WITH CHECK (
    household_id IN (
      SELECT household_id 
      FROM members 
      WHERE id = auth.uid()
    )
  );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_completions_task_id ON task_completions(task_id);
CREATE INDEX IF NOT EXISTS idx_completions_member_id ON task_completions(member_id);
CREATE INDEX IF NOT EXISTS idx_completions_household_id ON task_completions(household_id);
CREATE INDEX IF NOT EXISTS idx_completions_completed_at ON task_completions(completed_at DESC);

-- Create household_leaderboard view
CREATE OR REPLACE VIEW household_leaderboard AS
SELECT 
  m.id,
  m.household_id,
  m.display_name,
  m.avatar_url,
  m.role,
  COALESCE(SUM(tc.points_earned), 0)::integer AS total_points,
  COALESCE(COUNT(tc.id), 0)::integer AS tasks_completed,
  MAX(tc.completed_at) AS last_completion_at
FROM members m
LEFT JOIN task_completions tc ON tc.member_id = m.id
GROUP BY m.id, m.household_id, m.display_name, m.avatar_url, m.role;

-- Function to complete a task
CREATE OR REPLACE FUNCTION complete_task(
  p_task_id uuid,
  p_member_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_household_id uuid;
  v_task_difficulty smallint;
  v_points integer;
BEGIN
  -- Get task info
  SELECT household_id, difficulty INTO v_household_id, v_task_difficulty
  FROM tasks
  WHERE id = p_task_id AND deleted_at IS NULL;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Task not found';
  END IF;
  
  -- Verify member belongs to the household
  IF NOT EXISTS (
    SELECT 1 FROM members 
    WHERE id = p_member_id 
      AND household_id = v_household_id
  ) THEN
    RAISE EXCEPTION 'Member does not belong to this household';
  END IF;
  
  -- Calculate points based on difficulty
  v_points := CASE v_task_difficulty
    WHEN 1 THEN 10
    WHEN 2 THEN 20
    WHEN 3 THEN 30
    ELSE 10
  END;
  
  -- Update task last_completed_at
  UPDATE tasks
  SET last_completed_at = now()
  WHERE id = p_task_id;
  
  -- Create completion record
  INSERT INTO task_completions (task_id, member_id, household_id, points_earned)
  VALUES (p_task_id, p_member_id, v_household_id, v_points);
END;
$$;

-- Function to promote member to admin
CREATE OR REPLACE FUNCTION promote_to_admin(p_member_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_household_id uuid;
BEGIN
  -- Get target member's household
  SELECT household_id INTO v_household_id
  FROM members
  WHERE id = p_member_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Member not found';
  END IF;
  
  -- Verify caller is admin of the same household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = auth.uid()
      AND household_id = v_household_id
      AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only admins can promote members';
  END IF;
  
  -- Promote member
  UPDATE members
  SET role = 'admin'
  WHERE id = p_member_id;
END;
$$;

-- Function to demote admin to member
CREATE OR REPLACE FUNCTION demote_from_admin(p_member_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_household_id uuid;
  v_admin_count integer;
BEGIN
  -- Get target member's household
  SELECT household_id INTO v_household_id
  FROM members
  WHERE id = p_member_id AND role = 'admin';
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Admin member not found';
  END IF;
  
  -- Verify caller is admin of the same household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = auth.uid()
      AND household_id = v_household_id
      AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only admins can demote members';
  END IF;
  
  -- Check if this is the last admin
  SELECT COUNT(*) INTO v_admin_count
  FROM members
  WHERE household_id = v_household_id AND role = 'admin';
  
  IF v_admin_count <= 1 THEN
    RAISE EXCEPTION 'Cannot demote the last admin';
  END IF;
  
  -- Demote member
  UPDATE members
  SET role = 'member'
  WHERE id = p_member_id;
END;
$$;

-- Function to remove a member
CREATE OR REPLACE FUNCTION remove_member(p_member_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_household_id uuid;
  v_target_role text;
BEGIN
  -- Get target member's info
  SELECT household_id, role INTO v_household_id, v_target_role
  FROM members
  WHERE id = p_member_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Member not found';
  END IF;
  
  -- Verify caller is admin of the same household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = auth.uid()
      AND household_id = v_household_id
      AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only admins can remove members';
  END IF;
  
  -- Cannot remove yourself via this function
  IF p_member_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot remove yourself. Use leave_household instead';
  END IF;
  
  -- Delete member (cascade will handle related records)
  DELETE FROM members WHERE id = p_member_id;
END;
$$;

-- Function to leave household
CREATE OR REPLACE FUNCTION leave_household()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_household_id uuid;
  v_member_count integer;
  v_is_admin boolean;
  v_admin_count integer;
BEGIN
  -- Get current user's household and role
  SELECT household_id, (role = 'admin') INTO v_household_id, v_is_admin
  FROM members
  WHERE id = auth.uid();
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Not a member of any household';
  END IF;
  
  -- Count members in household
  SELECT COUNT(*) INTO v_member_count
  FROM members
  WHERE household_id = v_household_id;
  
  -- If last member, soft-delete the household
  IF v_member_count = 1 THEN
    UPDATE households
    SET deleted_at = now()
    WHERE id = v_household_id;
  ELSIF v_is_admin THEN
    -- Check if this is the last admin
    SELECT COUNT(*) INTO v_admin_count
    FROM members
    WHERE household_id = v_household_id AND role = 'admin';
    
    IF v_admin_count = 1 THEN
      RAISE EXCEPTION 'Cannot leave: you are the last admin. Promote another member first';
    END IF;
  END IF;
  
  -- Remove member
  DELETE FROM members WHERE id = auth.uid();
END;
$$;

-- Function to regenerate join code
CREATE OR REPLACE FUNCTION regenerate_join_code(p_household_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_code text;
BEGIN
  -- Verify caller is admin of this household
  IF NOT EXISTS (
    SELECT 1 FROM members
    WHERE id = auth.uid()
      AND household_id = p_household_id
      AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only admins can regenerate the join code';
  END IF;
  
  -- Generate new code
  new_code := generate_join_code();
  
  -- Update household
  UPDATE households
  SET join_code = new_code
  WHERE id = p_household_id;
  
  RETURN new_code;
END;
$$;

-- Function to delete account
CREATE OR REPLACE FUNCTION delete_account()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_household_id uuid;
  v_member_count integer;
  v_is_admin boolean;
  v_admin_count integer;
BEGIN
  -- Get current user's household info
  SELECT household_id, (role = 'admin') INTO v_household_id, v_is_admin
  FROM members
  WHERE id = auth.uid();
  
  IF FOUND THEN
    -- Count members and admins
    SELECT COUNT(*) INTO v_member_count
    FROM members
    WHERE household_id = v_household_id;
    
    SELECT COUNT(*) INTO v_admin_count
    FROM members
    WHERE household_id = v_household_id AND role = 'admin';
    
    -- If last member, soft-delete household
    IF v_member_count = 1 THEN
      UPDATE households
      SET deleted_at = now()
      WHERE id = v_household_id;
    ELSIF v_is_admin AND v_admin_count = 1 THEN
      RAISE EXCEPTION 'Cannot delete account: you are the last admin. Promote another member first';
    END IF;
  END IF;
  
  -- Delete from auth.users will cascade to members and other records
  DELETE FROM auth.users WHERE id = auth.uid();
END;
$$;
